# Custom queue operation: background work without blocking the UI

The Queue Manager (QM) lets you push slow work off the main thread so
Baselight/Daylight stays responsive. You click a menu item, it returns
*immediately*, and the job runs in the background where you can watch it in the
app's **QM view**.

A custom operation has two halves:

| File | Role | Runs where |
|------|------|-----------|
| `queue_demo_op.py` | App/UI script. Adds a menu item that builds a batch of tasks and hands them to the QM, then returns at once. | Loaded by the app (`Connection.get()`), deployed to `/vol/.support/scripts` |
| `process_demo_op.py` | Processor. Loaded by flapid; subscribes to the queue and runs each task, reporting progress. | Loaded by flapid (`Connection.get()`, event-driven), deployed to `/vol/.support/server-scripts` |

Both agree on the operation key `DEMO_OP_KEY = "DemoQueueOp"`. The "work" is a
fake timed sleep so the example is self-contained — replace the marked block in
`process_demo_op.py` with your real job (render, transcode, API call, …).

## Try it in Baselight

1. Symlink both scripts into place:
   ```
   ln -s "$PWD/queue_demo_op.py"   /vol/.support/scripts/queue_demo_op.py
   ln -s "$PWD/process_demo_op.py" /vol/.support/server-scripts/process_demo_op.py
   ```
2. Relaunch Baselight (registers the menu item; auto-starts the processor).
3. Confirm the app script loaded under *Views > Scripts* (no errors).
4. From the **App menu**, pick **"Queue Background Demo…"**, choose a task count
   and seconds-per-task, click OK.
5. Open the **QM view** and watch the operation progress and complete. The UI
   stays interactive the whole time — that's the point.

Teardown: `rm /vol/.support/scripts/queue_demo_op.py /vol/.support/server-scripts/process_demo_op.py`
