#!/usr/bin/env python3
"""
process_demo_op.py - Background processor for the custom queue operation.

This is the half that does the actual work, off the main UI thread. flapid
LOADS this script (runs its top level once) when the flapi service starts, so
it must set itself up and return: it subscribes to the Queue Manager and lets
flapid's event loop drive it. It must NOT open its own connection or sit in a
blocking loop.

It watches for operations of type DEMO_OP_KEY (queued by queue_demo_op.py) and
runs each task, reporting progress so a moving bar shows against the operation
in the app's QM view. The work is a fake timed sleep so the example is
self-contained; swap the marked block for your real job (render, transcode,
API call, ...). Because it runs here in flapid and not in the menu handler, the
Baselight/Daylight UI stays responsive the whole time.

Deploy: place (or symlink) this file in  /vol/.support/server-scripts
Reload after edits by restarting the flapi service:  sudo ./fl-service restart flapi

As a flapid server script it shares flapid's connection via Connection.get().
"""

import time
import flapi

DEMO_OP_KEY = "DemoQueueOp"


def run_task(opid, task):
    """Do one task's worth of work, reporting progress as it goes."""
    seconds = float(task.Params.get("seconds", 1.0))

    # ---- fake work: sleep in slices and report progress 0.0 -> 1.0 ----
    slices = max(1, int(seconds / 0.25))
    for i in range(slices):
        time.sleep(seconds / slices)
        qm.set_task_progress(opid, task.Seq, (i + 1) / slices)
    # -------------------------------------------------------------------

    qm.set_task_done(opid, task.Seq, f"Done: {task.Params.get('message', '')}")


def process(sender=None, signal=None, args=None):
    """Drain every ready DemoQueueOp operation. Driven by the signal/timer."""
    opid = qm.get_next_operation_of_type(DEMO_OP_KEY, 0)  # 0 = don't block
    if not opid:
        timer.stop()  # queue empty; idle until the next QueueOpsChanged
        return

    timer.start()
    total = qm.get_operation_params(opid).get("taskCount", 0)
    print(f"[demo-op] running operation {opid} ({total} task(s))", flush=True)

    count = 0
    task = qm.get_next_task(opid)
    while task is not None:
        count += 1
        qm.add_operation_log(opid, flapi.QUEUELOGTYPE_INFO,
                             f"Task {count} of {total}: {task.Desc}", "")
        run_task(opid, task)
        task = qm.get_next_task(opid)

    print(f"[demo-op] operation {opid} complete ({count} task(s))", flush=True)


# flapid server script -> use flapid's connection; set up handlers and return.
conn = flapi.Connection.get()
qm = conn.QueueManager.create_local()

# React when operations are added, and poll on a timer while we're busy.
qm.connect("QueueOpsChanged", process)
qm.enable_updates()

timer = conn.Timer.create(500)  # 500 ms
timer.connect("TimerTick", process)
timer.start()  # check once now; process() stops the timer when the queue is empty

print(f"[demo-op] loaded; watching queue for '{DEMO_OP_KEY}'", flush=True)
