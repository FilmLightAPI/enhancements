#!/usr/bin/env python3
"""
queue_demo_op.py - Run slow work in the background without blocking the UI.

This is the APP/UI half of a custom queue operation. The point of the Queue
Manager (QM) is to run long jobs *off* the main thread: the menu handler below
builds a batch of tasks, hands them to the QM, and returns immediately - so
Baselight/Daylight stays fully responsive while the work runs. You watch the
operation progress and finish in the app's QM view.

The matching processor that actually performs the work is process_demo_op.py.
Both must agree on DEMO_OP_KEY.

The "work" here is deliberately fake (a timed sleep per task) so the example is
self-contained; in real life this is where you'd queue renders, transcodes,
external API calls, etc. - anything you don't want to run inline on the UI.

Deploy: place (or symlink) this file in  /vol/.support/scripts
App scripts load when Baselight/Daylight launches; hot-reload from Views >
Scripts. As a UI script it shares the app's connection via Connection.get().
"""

import flapi

DEMO_OP_KEY = "DemoQueueOp"


class QueueDemoOpMenuItem:
    def __init__(self, conn):
        self.conn = conn
        # App menu so it's always available (no open scene required). For
        # shot-based work you'd register under MENULOCATION_SCENE_MENU instead.
        self.menu_item = conn.MenuItem.create("Queue Background Demo...")
        self.menu_item.register(flapi.MENULOCATION_APP_MENU)
        self.menu_item.connect("MenuItemSelected", self.on_selected)

    def on_selected(self, sender, signal, args):
        # Ask how much work to queue. Bump "Seconds per task" up if you want
        # plenty of time to watch the UI stay responsive while it runs.
        items = [
            flapi.DialogItem(Key="Count", Label="Number of tasks",
                             Type=flapi.DIT_INTEGER, IntMin=1, IntMax=100, Default=5),
            flapi.DialogItem(Key="Seconds", Label="Seconds per task",
                             Type=flapi.DIT_FLOAT, FloatMin=0.1, FloatMax=60.0, Default=2.0),
        ]
        settings = {"Count": 5, "Seconds": 2.0}

        dialog = self.conn.DynamicDialog.create("Queue Background Demo", items, settings)
        result = dialog.show_modal(-200, -50)
        if result:
            self.submit(int(result["Count"]), float(result["Seconds"]))

    def submit(self, count, seconds):
        # Build one task per unit of work. Each task's Params is whatever the
        # processor expects to receive.
        tasks = [
            flapi.QueueOpTask({
                "Type": "DemoTask",
                "Desc": f"Background task {i + 1}",
                "Params": {"message": f"task {i + 1}/{count}", "seconds": seconds},
                "Weight": 1.0,
            })
            for i in range(count)
        ]

        qm = self.conn.QueueManager.create_local()
        opid = qm.new_operation(
            DEMO_OP_KEY,                  # operation type key (processor must match)
            "Background demo operation",  # label shown in the QM view
            {"taskCount": len(tasks)},    # operation-level params
            tasks,
            None,
        )
        qm.release()

        # We return here straight away. The UI is never blocked - the work
        # happens in process_demo_op.py and shows up in the QM view.
        print(f"[demo-op] queued operation {opid} with {len(tasks)} task(s)", flush=True)


# UI script -> share the app's existing connection.
conn = flapi.Connection.get()
menu_item = QueueDemoOpMenuItem(conn)
